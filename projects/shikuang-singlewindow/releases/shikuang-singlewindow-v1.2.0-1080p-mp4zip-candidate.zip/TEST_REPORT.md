# TEST REPORT

- version: v1.2.0-1080p-mp4zip-candidate
- result: 34 passed, 7 subtests passed
- scope: rules, routing, state machine, 1080P engine execution, MP4+ZIP delivery verification
