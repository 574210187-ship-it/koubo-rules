# 实况视频单窗口｜v1.2.0-1080p-mp4zip-candidate｜跨账号公开入口

公开规则入口：https://raw.githubusercontent.com/574210187-ship-it/koubo-rules/shikuang-public-latest/projects/shikuang-singlewindow/START_HERE.md
公开项目目录：https://github.com/574210187-ship-it/koubo-rules/tree/shikuang-public-latest/projects/shikuang-singlewindow

最短启动口令：`启动实况 REVIEW` 或 `启动实况 AUTO`

## 核心规则
1. 读取本包全部 `rules/00~04`、`config/routes.json`、`config/engines.json` 与 `distribution/PUBLIC_USAGE.md`。缺文件或缺能力就停止，不得自改规则。
2. 两条视频时，画面里有明显正文文字的是对标视频；没有正文文字或正文很少的是主视频。也支持主视频+对标图片。不得按文件名和发送顺序硬判。
3. 00：真实查看并提取对标文字、位置、大小和排版，同时写入用户本轮改字要求；锁定主视频和对标素材哈希。
4. 01：只用 ImageGen 生成与主视频同比例的真实 RGBA 透明文字 PNG。尽量按对标还原大小和位置，不额外加装饰。
5. 02：不加速不减速，直接把 01 的透明文字图静态叠加到主视频上并导出。文字从首帧到末帧完全静止，保留主视频原声（如果有）。
6. 03：最终交付固定为两个文件：一个 **1080P MP4**，一个 **包含该 MP4 的 ZIP**。失败停在当前阶段，只重做当前阶段和下游阶段。

## 跨账号说明
- 其他 ChatGPT 账号可以先读这份入口，再下载或要求上传同版 ZIP。
- 能读 GitHub 规则，不等于已经有 ImageGen、FFmpeg、读视频和附件执行权限。
- AUTO 只有在账号确实具备这些能力时才能连续跑；缺能力时必须明确报缺口，不得假装完成。
