import json, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class TestProductionPolicy(unittest.TestCase):
 def test_playback_policy(self):
  p=json.loads((ROOT/'config/project.json').read_text())
  self.assertEqual(p['duration_policy'],'FULL_SOURCE_DURATION')
  self.assertEqual(p['playback'],'ORIGINAL_SPEED_FULL_DURATION')
 def test_no_motion(self):
  p=json.loads((ROOT/'config/project.json').read_text())
  self.assertEqual(p['text_motion'],'NONE')
 def test_imagegen_only(self):
  p=json.loads((ROOT/'config/project.json').read_text())
  self.assertEqual(p['image_generation'],'IMAGEGEN_ONLY')
 def test_delivery_spec(self):
  p=json.loads((ROOT/'config/project.json').read_text())
  self.assertEqual(p['output_video_profile'],'1080P')
  self.assertEqual(p['delivery_artifacts'],['MP4_1080P','ZIP_WITH_MP4'])
 def test_engine_not_auto_approved(self):
  e=json.loads((ROOT/'config/engines.json').read_text())
  self.assertTrue(all(x['status']!='APPROVED' for x in e['engines']))
if __name__=='__main__':unittest.main()
