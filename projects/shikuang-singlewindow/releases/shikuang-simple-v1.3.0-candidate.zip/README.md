# 实况视频单窗口（精简版）

一句话：**分析对标文字 → ImageGen生3～4张透明图供选 → 上传选中图后直接合成视频。**

环境：Python 3.10+、Pillow（仅只读检查PNG透明通道）、FFmpeg/ffprobe。ImageGen由ChatGPT图像工具实际调用，不是本地Python生成。无需联网运行脚本。

两份视频时先用画面看文字：有明显正文的是对标，没正文的是主视频。聊天窗口完成角色判断，把对应文件真实路径传入脚本。输入主视频和参考图片也支持。

## 00：分析并等“00通过”（REVIEW）
```bash
python src/shikuang.py init --run-dir runs/001 --main main.mp4 --reference reference.mp4 --mode REVIEW
```

视觉分析完成后准备简单的 `00.json`：
```json
{"text":"调到最后\n双方还有三百块差距\n法官：就当给我法院个面子行不行","layout":"三行左对齐，黑手写字，白纸条底衬，中下部","bbox":[0.03,0.52,0.94,0.16]}
```

如用户指定替换文字，直接填入 `text`，并在 `user_edits` 字段记下原话。继续：
```bash
python src/shikuang.py analyze --run-dir runs/001 --analysis 00.json
python src/shikuang.py approve-00 --run-dir runs/001
```

## 01：用 ImageGen 生三张，等待用户选

对刚确认的00内容分别实际调用ImageGen生成3张（要4张就调用4次），逐张展示，再登记原生文件和图像生成ID：
```bash
python src/shikuang.py options --run-dir runs/001 \
  --png candidate1.png --imagegen-id imagegen:真实生成ID1 \
  --png candidate2.png --imagegen-id imagegen:真实生成ID2 \
  --png candidate3.png --imagegen-id imagegen:真实生成ID3
```

## 02：用户把选中PNG发回来，直接制作视频

用户消息“用这张图片生成视频” + 选中PNG附件是唯一的制作触发。使用新附件准确路径：
```bash
python src/shikuang.py select --run-dir runs/001 --png user_selected.png
python src/shikuang.py render --run-dir runs/001
```

输出 `runs/001/outputs/final_001.mp4` 和 `runs/001/outputs/final_001.zip`。画面1080P，主视频全时长原速，文字绝对静止。自动进行技术验收。无需其它审批。

## 模式
REVIEW等00通过和用户选图。AUTO略过00人工审批，但也**必须等用户选择PNG**。没有 ImageGen 或 FFmpeg 则停在当前阶段，不允许谎报完成。

## 原版保护
本版不覆盖历史v1.2.0；旧版源码和ZIP留在旧版本目录。新的运行状态不可用旧版的`state.json`直接替代或静默迁移。
